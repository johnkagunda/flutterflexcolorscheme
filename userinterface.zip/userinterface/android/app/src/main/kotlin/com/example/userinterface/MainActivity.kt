package com.example.userinterface

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
